package com.spring.quickBanck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test021ApplicationTests {

	@Test
	void contextLoads() {
	}

}
