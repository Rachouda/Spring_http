package spring.APIClient.web;

import java.util.List;

import javax.validation.Valid;

import org.apache.catalina.connector.Response;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.json.WriterBasedJsonGenerator;

import spring.APIClient.dao.ClientRepository;
import spring.APIClient.dao.PostRepository;
import spring.APIClient.entities.Client;
import spring.APIClient.entities.Post;

@Controller
public class IndexController {
	@Autowired
	private PostRepository postRepoBean;
	
	@Autowired
	private ClientRepository clientRepoBean;
	
	@RequestMapping(value="/index")
	public String frontController() {
		return "index";
	}
	
	@RequestMapping(value="/clients")
	public String clientsController(
			Model model,
			@RequestParam(name = "motRech",defaultValue = "")String motRech,
			@RequestParam(name = "p",defaultValue = "0")int page,
			@RequestParam(name = "s",defaultValue = "5")int size)
	{
		Page<Client> allClients= clientRepoBean.chercher("%"+motRech+"%",PageRequest.of(page, size));
		model.addAttribute("listClients",allClients.getContent());
		return "clients";
	}
	
	
	@RequestMapping(value="/posts")
	
	public String postscontroller(
			Model model,
			@RequestParam(name = "motRech",defaultValue = "")String motRech,
			@RequestParam(name = "p",defaultValue = "0")int page,
			@RequestParam(name = "s",defaultValue = "5")int size
			)
	{
		Page<Post> allPosts= postRepoBean.chercher("%"+motRech+"%",PageRequest.of(page, size));
		model.addAttribute("listPosts",allPosts.getContent());
		return "posts";
	}
	
	@RequestMapping(value ="/del",method = RequestMethod.GET)
	//si on met ps methode par defaut c est get
	public String del(int id) {
		postRepoBean.deleteById(id);
		return "redirect:/posts";//redirection vers la vue "/posts"
	}
	
	@RequestMapping(value ="/redirectPosts")
	public String redirectPosts() {
		return "redirect:/posts";
		}
	

	@RequestMapping(value ="/redirectClients")
	public String redirectClients() {
		return "redirect:/clients";
		}
	
	@RequestMapping(value ="/redirectPostForum")
	public String redirectPostForum() {
		return "redirect:/formPost";
		}
	
	@RequestMapping(value ="/formPost")
	public String addPost(Model model) {
		model.addAttribute("formpost",new Post());
		return "formPost";
	}
	
	@RequestMapping(value = "saveFormPost",method = RequestMethod.POST)
	public String saveFormPost(Model model,@Valid Post formpost,
			BindingResult bindingResult/*collection des erreurs*/) {
		
		if(bindingResult.hasErrors())
			return "formPost";
		postRepoBean.save(formpost);
		System.out.println(formpost.getPosterName()+" posted with success");
		model.addAttribute("savedPost", formpost);
		return "postSaved";
	}
	


}
