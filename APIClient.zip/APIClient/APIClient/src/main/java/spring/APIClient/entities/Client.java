package spring.APIClient.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Client implements Serializable{
	@Id
	@GeneratedValue
	private int id;
	private String nom,Prenom,psw;
	private String CIN;
	private Date date_compte =new Date();
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return Prenom;
	}
	public void setEmail(String Prenom) {
		this.Prenom = Prenom;
	}
	public String getPsw() {
		return psw;
	}
	public void setPsw(String psw) {
		this.psw = psw;
	}
	public String getCIN() {
		return CIN;
	}
	public void setCIN(String CIN) {
		this.CIN = CIN;
	}
	public Date getDate_compte() {
		return date_compte;
	}
	public void setDate_compte(Date date_compte) {
		this.date_compte = date_compte;
	}
	public Client(String nom, String Prenom, String psw,String CIN) {
		super();
		this.nom = nom;
		this.Prenom = Prenom;
		this.psw = psw;
		this.CIN=CIN;
	}
	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
