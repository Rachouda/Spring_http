package spring.APIClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import spring.APIClient.dao.ClientRepository;
import spring.APIClient.dao.PostRepository;
import spring.APIClient.entities.Client;
import spring.APIClient.entities.Post;

@SpringBootApplication
public class ServerAPIClient {

	public static void main(String[] args) {
		ApplicationContext ctx=SpringApplication.run(ServerAPIClient.class, args);
		ClientRepository clientRepoBean=ctx.getBean(ClientRepository.class);
		PostRepository postRepoBean=ctx.getBean(PostRepository.class);
		clientRepoBean.save(new Client("admin", "Mh.Rach@gmail.com", "123abc"));
		postRepoBean.save(new Post("Rach","Mh.Rach@gmail.com","post a suprimé en test"));
		clientRepoBean.findAll().forEach(c->System.out.println(c.getNom()));
		postRepoBean.findAll().forEach(p->System.out.println(p.getIdPost()));
	}

}
