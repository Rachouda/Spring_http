package spring.APIClient.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

@Entity
public class Post implements Serializable{
	@Id
	@GeneratedValue
	private int idPost;
	private String posterName;
	@NotNull
	@Size(min =10,max = 30)
	private String posterMail;
	private String corp;
	public int getIdPost() {
		return idPost;
	}
	public void setIdPost(int idPost) {
		this.idPost = idPost;
	}
	public String getPosterName() {
		return posterName;
	}
	public void setPosterName(String posterName) {
		this.posterName = posterName;
	}
	public String getPosterMail() {
		return posterMail;
	}
	public void setPosterMail(String posterMail) {
		this.posterMail = posterMail;
	}
	public String getCorp() {
		return corp;
	}
	public void setCorp(String corp) {
		this.corp = corp;
	}
	public Post() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Post(String posterName, String posterMail, String corp) {
		super();
		this.posterName = posterName;
		this.posterMail = posterMail;
		this.corp = corp;
	}

	
}
